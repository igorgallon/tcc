# Frame resolution class

class Resolution():
    def __init__(self, w, h):
        self.width = w
        self.height = h