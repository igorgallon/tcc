class Messages():
    
    # Messages for Serial comunication
    msgTraining    = "TR\n";
    msgPredicting  = "PD\n";
    msgForward     = "FW\n";
    msgBackward    = "BW\n";
    msgLeft        = "LF\n";
    msgRight       = "RH\n";
    msgStop        = "ST\n";    